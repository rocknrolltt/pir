#!/bin/bash

USER=$1
PUBLIC_KEY_FILE=$2
echo "adding user $1 with public key $2"
adduser $USER
mkdir /home/$USER/.ssh
AUTHORIZED_KEYS=/home/$USER/.ssh/authorized_keys

cat $2 > $AUTHORIZED_KEYS
chown $USER $AUTHORIZED_KEYS
chmod 600 $AUTHORIZED_KEYS
